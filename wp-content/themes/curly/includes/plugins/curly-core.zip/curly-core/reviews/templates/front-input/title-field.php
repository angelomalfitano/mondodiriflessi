<div class="mkdf-comment-input-title">
    <label><?php esc_html_e('Title of your Review', 'curly-core') ?></label>
    <input id="title" name="mkdf_comment_title" class="mkdf-input-field" type="text" placeholder=""/>
</div>