<?php

include_once CURLY_CORE_SHORTCODES_PATH . '/counter/functions.php';
include_once CURLY_CORE_SHORTCODES_PATH . '/counter/counter.php';