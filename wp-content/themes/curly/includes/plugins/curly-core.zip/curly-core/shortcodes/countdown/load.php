<?php

include_once CURLY_CORE_SHORTCODES_PATH . '/countdown/functions.php';
include_once CURLY_CORE_SHORTCODES_PATH . '/countdown/countdown.php';