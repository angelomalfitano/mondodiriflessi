<?php

include_once CURLY_CORE_SHORTCODES_PATH . '/contact-form-7/functions.php';
