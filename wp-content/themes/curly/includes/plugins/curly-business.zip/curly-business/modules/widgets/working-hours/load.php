<?php

include_once CURLY_BUSINESS_WIDGETS_PATH . '/working-hours/functions.php';
include_once CURLY_BUSINESS_WIDGETS_PATH . '/working-hours/working-hours.php';